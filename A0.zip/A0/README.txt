Compilation:
	run in A0:
	premake5 make
	make
	./A0
Manual:
	no extra info 
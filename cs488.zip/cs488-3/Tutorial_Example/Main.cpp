// Fall 2023

#include "TutorialExample.hpp"

int main( int argc, char **argv ) 
{
	CS488Window::launch( argc, argv, new TutorialExample(), 800, 600,
			"Tutorial Example" );
	return 0;
}

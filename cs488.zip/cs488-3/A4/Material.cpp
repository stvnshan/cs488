// Termm--Fall 2023

#include "Material.hpp"

Material::Material()
{}

Material::~Material()
{}
